NEXTREPORT — 30-DAY ORGANIC LAUNCH PACK

Open NextReport_30_Day_Social_Plan.xlsx and start with START HERE.
Default dates: 17 November–16 December 2026. Set your own start date in B4.
Workbook dates recalculate. CSV exports retain the original dates.

WHAT IS INCLUDED
• 150 distinct posts: 30 each for LinkedIn, Facebook, Instagram, X and Reddit.
• Five platform tabs plus a combined master calendar (the same posts, not extras).
• Exact daily actions, source/claim notes, reply scripts, experiments and an empty results tracker.
• 30 portrait PNGs for Instagram/Facebook/LinkedIn and 30 landscape PNGs for X.
• UTF-8 CSV copies for convenient reference/copy-paste. Not a certified Zoho bulk-upload format.

SCHEDULING
Use your owned company/brand accounts. In Zoho choose the relevant channel,
paste the Caption cell, attach the matching PNG from Graphics, choose the date
and time, preview, and schedule. Set timezone to Asia/Kolkata; UTC is shown too.
Check your Zoho plan supports the network, account type and queue capacity.
Start with seven days rather than leaving the whole month unreviewed.

INSTAGRAM
Captions contain URLs as requested, but these are generally not clickable.
Set the fixed tagged homepage link from START HERE in your bio. Exact resource
URLs in captions are copyable; guides are also accessible on the site.
Use optional Story link stickers for a direct resource link. Bio traffic is not
reliably attributable to an individual feed post.

REDDIT
Do not bulk-schedule or blindly publish 30 standalone posts. Each day has a
useful draft; current community rules, account eligibility and relevance decide
whether to publish, adapt it into a reply to a real question, or skip.
RD-20 and RD-30 explicitly mention the product; only use in an approved feedback
or showcase thread. No links or branded images. Never hide your affiliation when
discussing your product. No automated pitches, keyword DMs or mass cross-posting.

GOOGLE SHEETS
Your provided Google Sheet was not edited. To use this workbook there:
File → Import → Upload → choose the XLSX → insert new sheets or replace the blank file.
Review formatting and dates after import.

PRODUCT AND CLAIMS
Prepared on 16 November 2026 from your document, current site content and source.
Current: Meta Ads; CSV or read-only API sync; weekly/monthly/comparison/daily;
PowerPoint/browser/Google Slides; seven-day trial, 3 clients, 10 reports, no card.
Google Ads/TikTok Ads/GA4 are planned. No PDF or scheduled-delivery claim.
Old document pricing, timing claims, discounts and unverifiable stories were removed.
Verify external-user API access, checkout and signup before broad promotion.

NO CONTENT HAS BEEN PUBLISHED OR SCHEDULED BY THIS PACK.
